<?php
include 'index.php';
var_dump(checkYahoo('albasha_007@yahoo.com'));