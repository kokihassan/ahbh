<?php
include 'index.php';
var_dump(checkGmail('kokihassan.yhoo.com@gmail.com'));